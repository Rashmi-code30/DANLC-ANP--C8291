a=int(input("Enter First number :"))
b=int(input("Enter Second number :"))
print("Addition of no. is:",a+b)
print("Subtraction of no. is:",a - b)
print("Multiplication of no. is:",a * b)
print("Division of no. is:",a / b)
print("Modulus of no. is:",a % b)



