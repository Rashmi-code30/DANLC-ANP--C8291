a=int(input("Enter the Base of triangle:"))
b=int(input("Enter the Height of triangle:"))
c=print("Area of triangle is :",(a*b)/2)