a=int(input("Enter total marks of 5 subjects:"))
c=print("Your total percentage is:",a/5)