a=int(input("Enter your Basic salary please:"))
print("Your bonus is:",a/10)